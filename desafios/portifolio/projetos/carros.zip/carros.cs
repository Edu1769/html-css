/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
using System.IO;

class HelloWorld 
{
  static void Main() 
  {
    string Selecione="", ponto, user, formPag="", marca="", nome="", cpf="", endereço;
    string carroUsado="";
    string CarNov = @"carros.txt";
    string CarUse = @"CarrosUsados.txt";
    int i=0, a=0, b=0;
    int c1, c2, c3;
    string[,] Carros = new string[6,6];
    string[,] CarroUse = new string[6,6];
    
    while(Selecione!="1" && Selecione!="2" && Selecione!="3")
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(" ====================================================================");
        Console.ResetColor();
        Console.WriteLine("\n\t\t\tLOJA DE VENDA DE VEICULOS\n");
        
        
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(" ====================================================================\n");
        Console.ResetColor();
        
            
        Console.WriteLine("  *Escolha uma das opcoes:");
        Console.WriteLine("   1) Comprar novo carro");
        Console.WriteLine("   2) Comprar carro usado");
        Console.WriteLine("   3) Sair");
        Console.Write("  Escolha: ");
        Selecione = Console.ReadLine();
        Console.Clear();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    if(Selecione=="1")
    {
        foreach (string s in File.ReadAllLines(CarNov))
        {
            i=0;
            user="";
            while(i<s.Length)
            {
                ponto = s.Substring(i,1);
                if(ponto==";")
                {
                    
                    Carros[a,b]= user;
                    a++;
                    if(a==6)
                    {
                        a=0;
                        b++;
                    }
                    user="";
                }
                else
                {
                    user = string.Concat(user,ponto); 
                }
                i++;
                
            }
        }
    }
    if(Selecione=="2")
    {
        foreach (string s in File.ReadAllLines(CarUse))
        {
            i=0;
            user="";
            while(i<s.Length)
            {
                ponto = s.Substring(i,1);
                if(ponto==";")
                {
                    
                    Carros[a,b]= user;
                    a++;
                    if(a==6)
                    {
                        a=0;
                        b++;
                    }
                    user="";
                }
                else
                {
                    user = string.Concat(user,ponto); 
                }
                i++;
                
            }
        }
    }
        while(nome.Length<3)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Nome do usuario");
            Console.WriteLine(" - O nome deve conter de 3 a 10 caracteres");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" Informe seu nome: ");
            nome = Console.ReadLine();
            Console.Clear();
        }
        
        while(cpf.Length<11)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Cpf do usuario");
            Console.WriteLine(" - O cpf deve conter 11 digitos");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" Informe seu cpf: ");
            cpf = Console.ReadLine();
            Console.Clear();
            
        }
        
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("_________________________________________________________");
        Console.ResetColor();
        Console.WriteLine("\n - Endereço do usuario");
        Console.WriteLine(" - A designação da residência de uma pessoa");
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("_________________________________________________________\n");
        Console.ResetColor();
        Console.Write(" Informe seu endereço: ");
        endereço = Console.ReadLine();
        Console.Clear();
        
        while(marca!=Carros[0,0].ToUpper() && marca!=Carros[0,1].ToUpper() && marca!=Carros[0,2].ToUpper() && marca!=Carros[0,3].ToUpper() && marca!=Carros[0,4].ToUpper() && marca!=Carros[0,5].ToUpper())
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" ====================================================================================================================");
            Console.ResetColor();
            Console.WriteLine(" Carros disponiveis: \n");
            Console.WriteLine("\t  Marca\t\tModelo\t\tAno\t\tCor\t\tPlaca\t\tValor");
            Console.WriteLine("\t----------------------------------------------------------------------------------------");
            Console.WriteLine("\t  "+Carros[0,0]+"\t\t"+Carros[1,0]+"\t\t"+Carros[2,0]+"\t\t"+Carros[3,0]+"\t\t"+Carros[4,0]+"\t"+Carros[5,0]  );
            Console.WriteLine("\t  "+Carros[0,1]+"\t"+Carros[1,1]+"\t\t"+Carros[2,1]+"\t\t"+Carros[3,1]+"\t\t"+Carros[4,1]+"\t"+Carros[5,1]  );
            Console.WriteLine("\t  "+Carros[0,2]+"\t\t"+Carros[1,2]+"\t\t"+Carros[2,2]+"\t\t"+Carros[3,2]+"\t"+Carros[4,2]+"\t"+Carros[5,2]  );    
            Console.WriteLine("\t  "+Carros[0,3]+"\t"+Carros[1,3]+"\t\t"+Carros[2,3]+"\t\t"+Carros[3,3]+"\t\t"+Carros[4,3]+"\t"+Carros[5,3]  );
            Console.WriteLine("\t  "+Carros[0,4]+"\t"+Carros[1,4]+"\t\t"+Carros[2,4]+"\t\t"+Carros[3,4]+"\t\t"+Carros[4,4]+"\t"+Carros[5,4]  );  
            Console.WriteLine("\t  "+Carros[0,5]+"\t"+Carros[1,5]+"\t\t"+Carros[2,5]+"\t\t"+Carros[3,5]+"\t"+Carros[4,5]+"\t"+Carros[5,5]  );  
            
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" ====================================================================================================================\n");
            Console.ResetColor();
            
            Console.WriteLine("  *Coloque o nome do carro que deseja comprar: ");
            Console.Write("   Escolha: ");
            marca = Console.ReadLine().ToUpper();
            Console.Clear();
        }
        
        for(i=0;i<6;i++)
        {
            if(marca==Carros[0,i].ToUpper())
            {
                a=i;
            }
        }
        
        while(formPag!="1" && formPag!="2")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" ====================================================================");
            Console.ResetColor();
            Console.WriteLine("  Carro: "+Carros[0,a]+" | Preco: "+Carros[5,a]);
            
            
            Console.WriteLine("\n  *Formas de pagamento:");
            Console.WriteLine("   1) Dinheiro");
            Console.WriteLine("   2) Carro de entrada");
            Console.Write("   Escolha: ");
            formPag = Console.ReadLine();
            Console.Clear();
        }
        if(formPag=="1")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n ====================================================================\n");
            Console.ResetColor();
            Console.WriteLine("  Carro comprado: "+Carros[0,a]+" | "+Carros[1,a]+" | "+Carros[2,a]+" | "+Carros[3,a]+" | "+Carros[4,a]);
            Console.WriteLine("\n  Comprado por "+nome.ToUpper()+" por: R$ "+Carros[5,a]);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n ====================================================================");
            Console.ResetColor();
        }
        if(formPag=="2")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n ====================================================================\n");
            Console.ResetColor();
            Console.Write(" Informe Marca do carro: ");
            CarroUse[0,a] = Console.ReadLine();
            Console.Write(" Informe Modelo do carro: ");
            CarroUse[1,a] = Console.ReadLine();
            Console.Write(" Informe Ano do carro: ");
            CarroUse[2,a] = Console.ReadLine();
            Console.Write(" Informe Cor do carro: ");
            CarroUse[3,a] = Console.ReadLine();
            Console.Write(" Informe Placa do carro: ");
            CarroUse[4,a] = Console.ReadLine();
            Console.Write(" Informe Valor do carro: ");
            CarroUse[5,a] = Console.ReadLine();
            
            
            c1 = Convert.ToInt32(Carros[5,a]);
            c2 = Convert.ToInt32(CarroUse[5,a]);
            
            Carros[0,a]= CarroUse[0,a];
            Carros[1,a]= CarroUse[1,a];
            Carros[2,a]= CarroUse[2,a];
            Carros[3,a]= CarroUse[3,a];
            Carros[4,a]= CarroUse[4,a];
            Carros[5,a]= CarroUse[5,a];
            
            
            
            if(c1<=c2)
            {
                c3 = 0;
            }
            else
            {
                c3 = c1 - c2;    
            }
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n ====================================================================\n");
            Console.ResetColor();
            Console.WriteLine("  Carro comprado: "+Carros[0,a]+" | "+Carros[1,a]+" | "+Carros[2,a]+" | "+Carros[3,a]+" | "+Carros[4,a]);
            Console.WriteLine("\n  Comprado por "+nome.ToUpper()+" por: R$ "+c3);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n ====================================================================");
            Console.ResetColor();
            
            
            
            File.Delete(CarUse);
            
            a=0;
            for(i=0;i<6;i++)
            {
                carroUsado = string.Concat(Carros[0,a]+";"+Carros[1,a]+";"+Carros[2,a]+";"+Carros[3,a]+";"+Carros[4,a]+";"+Carros[5,a]+";\n");
                if(!File.Exists(CarUse))
                {
                    File.WriteAllText(CarUse,carroUsado);
                }
                else
                {
                    File.AppendAllText(CarUse,carroUsado);
                }
                a++;
            }
            
        }
    }
}