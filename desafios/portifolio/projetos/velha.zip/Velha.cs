/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld 
{
  static void Main() 
  {
    
    string[,] Velha = new string [20,20];
    Velha[0,0]=" ";
    Velha[0,1]=" ";
    Velha[0,2]=" ";
    Velha[1,0]=" ";
    Velha[1,1]=" ";
    Velha[1,2]=" ";
    Velha[2,0]=" ";
    Velha[2,1]=" ";
    Velha[2,2]=" ";
    
    string jog="", letra="", num="";
    int jog1=0, jog2=0, round=0;
    int i=0, j=0, a=0;
    bool jogo= true;
    
    
    letra T = new letra();
    
    
    while(jog!="1A" && jog!="1B" && jog!="1C" && jog!="2A" && jog!="2B" && jog!="2C" && jog!="3A" && jog!="3B" && jog!="3C")
    {
        
        
        Console.Clear();
        
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("=====================================================\n");
        Console.ResetColor();
        Console.WriteLine("\t BEM VINDO AO JOGO DA VELHA ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\n=====================================================");    
        Console.ResetColor();
        
        
        
        
        Console.WriteLine("\n\n");
        Console.WriteLine("   \t|1|   |2|   |3|   \n");
        Console.WriteLine(" |A|\t "+Velha[0,0]+"  |  "+Velha[0,1]+"  |  "+Velha[0,2]+"   \t| Para realizar uma");
        Console.WriteLine("   \t=============== \t| jogada, escreva a");
        Console.WriteLine(" |B|\t "+Velha[1,0]+"  |  "+Velha[1,1]+"  |  "+Velha[1,2]+"   \t| posição. ex: 2b");
        Console.WriteLine("   \t===============   ");
        Console.WriteLine(" |C|\t "+Velha[2,0]+"  |  "+Velha[2,1]+"  |  "+Velha[2,2]+"   \t");
        
        if((Velha[0,0]=="X" && Velha[0,1]=="X" && Velha[0,2]=="X") || (Velha[0,0]=="X" && Velha[1,0]=="X" && Velha[2,0]=="X") || (Velha[0,0]=="X" && Velha[1,1]=="X" && Velha[2,2]=="X") || (Velha[2,2]=="X" && Velha[1,2]=="X" && Velha[0,2]=="X") || (Velha[2,2]=="X" && Velha[2,1]=="X" && Velha[2,0]=="X")  || (Velha[2,2]=="X" && Velha[1,1]=="X" && Velha[0,0]=="X") || (Velha[0,2]=="X" && Velha[1,1]=="X" && Velha[2,0]=="X") || (Velha[1,0]=="X" && Velha[1,1]=="X" && Velha[1,2]=="X") || (Velha[0,1]=="X" && Velha[1,1]=="X" && Velha[2,1]=="X"))
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\tPARABENS VOCE VENCEU");
            break;
        }
        if((Velha[0,0]=="O" && Velha[0,1]=="O" && Velha[0,2]=="O") || (Velha[0,0]=="O" && Velha[1,0]=="O" && Velha[2,0]=="O") || (Velha[0,0]=="O" && Velha[1,1]=="O" && Velha[2,2]=="O") || (Velha[2,2]=="O" && Velha[1,2]=="O" && Velha[0,2]=="O") || (Velha[2,2]=="O" && Velha[2,1]=="O" && Velha[2,0]=="O")  || (Velha[2,2]=="O" && Velha[1,1]=="O" && Velha[0,0]=="O") || (Velha[0,2]=="O" && Velha[1,1]=="O" && Velha[2,0]=="O") || (Velha[1,0]=="O'" && Velha[1,1]=="O" && Velha[1,2]=="O") || (Velha[0,1]=="O" && Velha[1,1]=="O" && Velha[2,1]=="O"))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\tVOCE PERDEU");
            break;
        }
        if(Velha[0,0]!=" " && Velha[0,1]!=" " && Velha[0,2]!=" " && Velha[1,0]!=" " && Velha[1,1]!=" " && Velha[1,2]!=" " && Velha[2,0]!=" " && Velha[2,1]!=" " && Velha[2,2]!=" ")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\tEMPATE");
            break;
            
        }
        jogo = true;
        
        
        
        if(round%2==0)
        {
            Console.Write("\n\n Faça sua jogada: ");
            jog = Console.ReadLine().ToUpper();
            
            
            if(jog!="1A" && jog!="1B" && jog!="1C" && jog!="2A" && jog!="2B" && jog!="2C" && jog!="3A" && jog!="3B" && jog!="3C")
            {
                jog="";    
            }
            else
            {
                letra = jog.Substring(1,1);
                num = jog.Substring(0,1);
                jog1 = T.transfLet(letra, jog1);
                jog2 = T.transfNum(num, jog2);
             
                if(Velha[jog1,jog2]!=" ")
                {
                    jog=" ";
                 
                }
                else
                {
                    Velha[jog1,jog2]="X";
                    Console.Clear();
                }
                                
            }
        }
        
        
        
        
        
        if(round%2!=0)
        {
            for(i=0;i<3;i++)
            {
                for(j=0;j<3;j++)
                {
                    if(Velha[i,0]=="X" && Velha[i,1]=="X" && Velha[i,2]==" ")
                    {
                        Velha[i,j+2]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,j]=="X" && Velha[1,j]=="X" && Velha[2,j]==" ")
                    {
                        Velha[i+2,j]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,0]=="X" && Velha[1,1]=="X" && Velha[2,2]==" ")
                    {
                        Velha[2,2]="O";
                        jogo = false;
                        break;
                    }
                    
                    else if(Velha[i,2]=="X" && Velha[i,1]=="X" && Velha[i,0]==" " )
                    {
                        Velha[i,0]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[2,j]=="X" && Velha[1,j]=="X" && Velha[0,j]==" ")
                    {
                        Velha[0,j]="O";
                        jogo = false;
                        break;
                    }
                 
                    else if(Velha[2,2]=="X" && Velha[1,1]=="X" && Velha[0,0]==" ")
                    {
                        Velha[0,0]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,2]=="X" && Velha[1,1]=="X" && Velha[2,0]==" ")
                    {
                        Velha[2,0]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[2,0]=="X" && Velha[1,1]=="X" && Velha[0,2]==" ")
                    {
                        Velha[0,2]="O";
                        jogo = false;
                        break;
                    }
                    
                    else if(Velha[i,0]=="X" && Velha[i,2]=="X" && Velha[i,1]==" ")
                    {
                        Velha[i,1]="O";
                        jogo = false;
                        break; 
                    }
                    else if(Velha[0,2]=="X" && Velha[2,0]=="X" && Velha[1,1]==" ")
                    {
                        Velha[1,1]="O";
                        jogo = false;
                        break;
                    }
                    else if (Velha[0,0]=="X" && Velha[2,2]=="X" && Velha[1,1]==" ")
                    {
                        Velha[1,1]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,j]=="X" && Velha[2,j]=="X" && Velha[1,j]==" ")
                    {
                        Velha[1,j]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[i,0]=="O" && Velha[i,1]=="O" && Velha[i,2]==" ")
                    {
                        Velha[i,j+2]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,j]=="O" && Velha[1,j]=="O" && Velha[2,j]==" ")
                    {
                        Velha[i+2,j]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,0]=="O" && Velha[1,1]=="O" && Velha[2,2]==" ")
                    {
                        Velha[2,2]="O";
                        jogo = false;
                        break;
                    }
                    
                    else if(Velha[i,2]=="O" && Velha[i,1]=="O" && Velha[i,0]==" " )
                    {
                        Velha[i,0]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[2,j]=="O" && Velha[1,j]=="O" && Velha[0,j]==" ")
                    {
                        Velha[0,j]="O";
                        jogo = false;
                        break;
                    }
                    
                    else if(Velha[2,2]=="O" && Velha[1,1]=="O" && Velha[0,0]==" ")
                    {
                        Velha[0,0]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,2]=="O" && Velha[1,1]=="O" && Velha[2,0]==" ")
                    {
                        Velha[2,0]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[2,0]=="O" && Velha[1,1]=="O" && Velha[0,2]==" ")
                    {
                        Velha[0,2]="O";
                        jogo = false;
                        break;
                    }
                    
                    else if(Velha[i,0]=="O" && Velha[i,2]=="O" && Velha[i,1]==" ")
                    {
                        Velha[i,1]="O";
                        jogo = false;
                        break; 
                    }
                    else if(Velha[0,2]=="O" && Velha[2,0]=="O" && Velha[1,1]==" ")
                    {
                        Velha[1,1]="O";
                        jogo = false;
                        break;
                    }
                    else if (Velha[0,0]=="O" && Velha[2,2]=="O" && Velha[1,1]==" ")
                    {
                        Velha[1,1]="O";
                        jogo = false;
                        break;
                    }
                    else if(Velha[0,j]=="O" && Velha[2,j]=="O" && Velha[1,j]==" ")
                    {
                        Velha[1,j]="O";
                        jogo = false;
                        break;
                    }
                }
                if(jogo==false)
                {
                    break;
                }
            }
            
            if (jogo==true)
            {
                for(i=0;i<3;i++)
                {
                    if(jogo==false)
                    {
                        break;
                    }
                    for(j=0;j<3;j++)
                    {
                        if(Velha[i,j]==" ")
                        {
                            Velha[i,j]="O";
                            jogo=false;
                            break;
                        }
                    }
                   
                }
            }
        }
        
        if(jog=="" || Velha[jog1,jog2]=="O")
        {
            round=0;
        }
        else
        {
            jog="";    
            round++;
        }
    }
    }
  }