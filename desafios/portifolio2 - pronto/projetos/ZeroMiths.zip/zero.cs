/******************************************************************************

coisas a fazer:
Nosso jogo C) um mmo 
precisamos de um nome pro jogo
Coisas a colocar: classe , nickname dentro do jogo, e arrumar algumas coisas no programa
adicionar os laC'os de repetiC'C#o
colocar se o usuario quer se registrar ou logar..
1234.j
COLOCAR TERMOS DE SERVICO,
*******************************************************************************/
using System;
using System.IO;

class Mitlogia_mmorpg
{
    static void Main() 
    {

    usuario NewUse = new usuario();  
    Personagem perso = new Personagem();
    

    string path = @"C:Cadastros.txt";
    string ficha = @"C:ficha.txt";
    string concats, confirm="", user="", ponto;
    string crenc="", ra="", clas="";
    bool n1= false, n2=false, n3=false, s1=false, u1= false;
    int cont=0, i=0, j=0; 
    
    Console.ForegroundColor = ConsoleColor.Yellow;
    NewUse.Tela();
    Console.ReadKey();
    Console.Clear();
    
    
    while(confirm!="3")
    {
        NewUse.DataNasc=0;
        NewUse.senha=" ";
        NewUse.nome="";
        NewUse.confirmEmail="";
        confirm =" ";
        NewUse.userName="";
        
        while(confirm!="3" && confirm!="2" && confirm!="1")
        {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("_________________________________________________________\n");
        Console.ResetColor();
        Console.WriteLine("  *Escolha uma das opcoes:");
        Console.WriteLine("   1) Cadastro");
        Console.WriteLine("   2) Login");
        Console.WriteLine("   3) Sair");
        if(cont==5)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  *Cadastro realizado com sucesso!!");
            Console.ResetColor();
            cont=0;
        }
        
        if(confirm!="1" && confirm!="2" && confirm!="3")
        {
            if(cont>0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("   Opcao invalida!!");
                Console.ResetColor();
                cont=0;
            }
        }
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("_________________________________________________________\n");
        Console.ResetColor();
        Console.Write(" Selecione o numero: ");
        confirm= Console.ReadLine();
        
        if(confirm!="1" && confirm!="2" && confirm!="3")
        {
            cont++;
        }    
        Console.Clear();
        }
        
        if(confirm=="1")
        {
        while (NewUse.nome.Length<3 || NewUse.nome.Length>20)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Nome de login");
            Console.WriteLine(" - O nome deve conter de 3 a 10 caracteres");
            if(cont>0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" - Nome invalido!!");
                Console.ResetColor();
                cont=0;
            }
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" Informe seu nome: ");
            NewUse.nome = Console.ReadLine();
            if(NewUse.nome.Length<3)
            {
                cont++;
            }
            Console.Clear();
        }
        
        while (NewUse.userName.Length<5 || NewUse.userName.Length>20)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Nickname");
            Console.WriteLine(" - Nome em jogo");
            Console.WriteLine(" - O nickname deve conter de 5 a 20 caracteres");
            if(cont>0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" - Nome invalido!!");
                Console.ResetColor();
                cont=0;
            }
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" Informe nickname: ");
            NewUse.userName = Console.ReadLine();
            if(NewUse.userName.Length<5)
            {
                cont++;
            }
            Console.Clear();
        }
        
        
        while (NewUse.senha != NewUse.confirmSenha)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Senha de login");
            Console.WriteLine(" - Senha deve conter uma letra maiuscula");
            Console.WriteLine(" - Senha deve conter 5 a 15 characteres");
            if(cont>0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" - senha invalida!!");
                Console.ResetColor(); 
                cont=0;
            }
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");  
            Console.ResetColor();
            Console.Write(" Informe senha: ");
            NewUse.senha= Console.ReadLine();
            if(NewUse.senha.Length>4 && NewUse.senha.Length<15)
            {
                Console.Write("\n Confirmar senha: ");
                NewUse.confirmSenha = Console.ReadLine();
                if(NewUse.senha!=NewUse.confirmSenha)
                {
                    cont++;
                }
                
            }
            else 
            {
                cont++;
            }
            
            Console.Clear();
        }
        
        while (NewUse.DataNasc<11111111 )
        {
        try
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Data de nascimento\n - Colocar em formato AAAAMMDD");
            if (cont>0)
            {
                if (NewUse.DataNasc<11111111 && NewUse.DataNasc>111111111)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" - As datas estao invaldias!!");
                    Console.ResetColor();    
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" - As datas estao diferentes!!");
                    Console.ResetColor();
                }
                cont=0;
            }
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" data de nascimento: ");
            NewUse.DataNasc = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n confirmar data: ");
            NewUse.confirmdata = Convert.ToInt32(Console.ReadLine());
            if (NewUse.confirmdata!=NewUse.DataNasc || NewUse.DataNasc<11111111 || NewUse.DataNasc>111111111)
            {
                NewUse.DataNasc=0;
                cont++;
            }
            NewUse.idade = Convert.ToString(20210917-NewUse.DataNasc).Substring(0,2);
            Console.Clear();
        }
        catch
        {
            Console.Clear();
            Console.WriteLine("atenção!!");
            Console.WriteLine("Usar somente numeros!!");
        }
        }
        
        while(NewUse.confirmEmail!= "@gmail.com" && NewUse.confirmEmail != "utlook.com")
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________");
            Console.ResetColor();
            Console.WriteLine("\n - Endereço de email");
            Console.WriteLine(" - O Email deve possuir um endereço");
            Console.WriteLine(" - @outlook.com ou @gmail.com");
            if(cont>0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" - Email invalido!!");
                Console.ResetColor();
                cont=0;
            }
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" Informe email: ");
            NewUse.email = Console.ReadLine();
            if(NewUse.email.Length>10)
            {
                NewUse.confirmEmail = NewUse.email.Substring(NewUse.email.Length-10,10);
                if(NewUse.confirmEmail!= "@gmail.com" && NewUse.confirmEmail!= "utlook.com" )
                {
                    cont++;
                }
                else
                {
                    cont=5;
                }
            }
            Console.Clear();
        }
        
        concats = string.Concat(NewUse.nome+";"+NewUse.senha+";"+NewUse.userName+";"+NewUse.idade+";"+NewUse.email+";\n");
        if(!File.Exists(path))
        {
            File.WriteAllText(path,concats);
        }
        else
        {
            File.AppendAllText(path,concats);
        }
        
    }
    
    else if(confirm=="2")
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("_________________________________________________________________");
        Console.ResetColor();
        Console.WriteLine("\n - Para retornar ao menu digite 0 no nome!!!\n - Informar o nome e senha cadastrado");
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("_________________________________________________________________\n");
        Console.ResetColor();
        Console.Write(" Informe seu nome: ");
        NewUse.nome = Console.ReadLine();
        if(NewUse.nome!= "0")
        {
        perso.classe=0;
        perso.raça=0;
        perso.crença=0;
        n1=false;
        n2=false;
        n3=false;
        s1=false;
        u1=false;
        
        Console.Write("\n Informe sua senha: ");
        NewUse.senha = Console.ReadLine();
        foreach (string s in File.ReadAllLines(path))
        {
            i=0;
            user="";
            while(i<s.Length)
            {
                ponto = s.Substring(i,1);
                if(ponto==";")
                {
                    if(u1== false)
                    {
                        if(n1==true && s1== true)
                        {
                            u1= true;
                            NewUse.userName= user;
                        }
                    }
                    if(user == NewUse.nome)
                    {
                        n1=true;
                        
                    }
                    if(user == NewUse.senha)
                    {
                        s1=true;
                    }
                    user="";
                    
                }
                else
                {
                    user = string.Concat(user,ponto); 
                }
                i++;
            }
            
        }
        
        foreach (string s in File.ReadAllLines(ficha))
        {
            i=0;
            user="";
            while(i<s.Length)
            {
                ponto = s.Substring(i,1);
                if(ponto==";")
                {
                    if(user == NewUse.nome)
                    {
                        n2=true;
                        
                    }
                    user="";
                    
                }
                else
                {
                    user = string.Concat(user,ponto); 
                }
                i++;
            }
            
        }
        
        
        try 
        {
        if (n2 == false)
        {
        if (n1 == true && s1 == true)
        {
            
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________________________\n");
            Console.ResetColor();
            Console.Write(" BEM VINDO ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(NewUse.userName.ToUpper());
            Console.ResetColor();
            Console.Write(", Para terminar seu registo");
            Console.WriteLine("\n Crie seu Personagem com base no seu gosto"); 
            Console.WriteLine(" Lembre-se que cada opção muda a sua characteristica em jogo");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\n_________________________________________________________________________");
            Console.ResetColor();
            Console.Write("\nPressione qualquer tecla para continuar...");
            Console.ReadKey();
            Console.Clear();
            while(perso.classe!=1 && perso.classe!=2 && perso.classe!=3 && perso.classe!=4)
            {
                perso.heroi1();
                Console.Write("\n *Escolha uma classe: ");
                perso.classe = Convert.ToInt32(Console.ReadLine());  
                Console.Clear();
                switch(perso.classe)
                {
                    case 1:
                        clas = "Necromante";
                        break;
                    case 2:
                        clas = "Guerreiro";
                        break;
                    case 3:
                        clas = "Assasino";
                        break;
                    case 4: 
                        clas = "Paladino";
                        break;
                }
            }
            
            while(perso.raça!=1 && perso.raça!=2 && perso.raça!=3 && perso.raça!=4)
            {
                perso.heroi2();
                Console.Write("\n *Escolha uma raca: ");
                perso.raça = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                switch(perso.raça)
                {
                    case 1:
                        ra = "Anao";
                        break;
                    case 2:
                        ra = "Gigante";
                        break;
                    case 3:
                        ra = "Elfo";
                        break;
                    case 4: 
                        ra = "fada";
                        break;
                }
            }
            
            while(perso.crença!=1 && perso.crença!=2 && perso.crença!=3 && perso.crença!=4)
            {
                perso.heroi3();
                Console.Write("\n *Escolha uma classe: ");
                perso.crença = Convert.ToInt32(Console.ReadLine());  
                Console.Clear();
                switch(perso.crença)
                {
                    case 1:
                        crenc = "Grega";
                        break;
                    case 2:
                        crenc = "Africana";
                        break;
                    case 3:
                        crenc = "Brasileira";
                        break;
                    case 4: 
                        crenc = "Nordica";
                        break;
                    
                }
            }
           
            concats = string.Concat(NewUse.nome+";"+clas+";"+ra+";"+crenc+";\n");
            if(!File.Exists(ficha))
            {
                File.WriteAllText(ficha,concats);
            }
            else
            {
                File.AppendAllText(ficha,concats);
            }
            n2= true;
        }
        else 
        {
            cont++;
        }
        }
        if (n2 == true && s1 == true)
        {
            foreach (string s in File.ReadAllLines(ficha))
            {
                i=0;
                user="";
                while(i<s.Length)
                {
                    ponto = s.Substring(i,1);
                    if(ponto==";")
                    {
                        if(n3 == true)
                        {
                            if(j==0)
                            {
                                clas = user;
                            }
                            if(j==1)
                            {
                                ra=user;
                            }
                            if(j==2)
                            {
                                crenc = user;
                            }
                            j++;
                        }    
                        if(user == NewUse.nome)
                        {
                            n3= true;
                        }
                        
                        user="";
                        
                        
                    }
                    else
                    {
                        user = string.Concat(user,ponto); 
                    }
                i++;
                }
            }
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("_________________________________________________________________________\n");
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("\tFICHA DE USUARIO:");   
            Console.ResetColor();
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t Nome: ");
            Console.ResetColor();
            Console.Write(NewUse.nome.ToUpper());
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t\t\t\t\t Level: ");
            Console.ResetColor();
            Console.Write("0");
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t Classe: " );
            Console.ResetColor();
            Console.Write(clas);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t\t\t\t\t Missoes: ");
            Console.ResetColor();
            Console.Write("0");
            
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t Raca: ");
            Console.ResetColor();
            Console.Write(ra);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t\t\t\t\t Conquistas: ");
            Console.ResetColor();
            Console.Write("0");
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n\t Crenca: ");
            Console.ResetColor();
            Console.Write(crenc);
            
            
            
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\n_________________________________________________________________________\n");
            Console.ResetColor();
            
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("\n\tHISTORIA:");   
            Console.ResetColor();
            Console.WriteLine("\n\t*Nas montanhas das mais antigas terras, ");
            Console.WriteLine("\thávia um lugar cujo acompanhava nossos sonhos");
            Console.WriteLine("\te enchia nossa imaginação com histórias");
            Console.WriteLine("\tsobre seres fantásticos, dotados de poderes sobre-humanos,");
            Console.WriteLine("\te que desafiam nossa mente e realidade"); 
            Console.WriteLine("\tPorém, uma nevoa encheu os corações");
            Console.WriteLine("\tdos mais nobres cavaleiros das terras");
            Console.WriteLine("\tLevando o caos a famosa terra de Zero Miths,");
            Console.WriteLine("\tDiversos guerreiros ainda tentam trazer");
            Console.WriteLine("\tde volta a fantastica terra para o mundo,");
            Console.WriteLine("\tPorém, poucos realmente conseguem entrar nela,");
            Console.WriteLine("\tMas um em especial apareceu nas colinas de");
            Console.Write("\tzagareth, e seu nome é: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(NewUse.userName);
            Console.ResetColor();
            
            Console.ResetColor();
            Console.ReadKey();
        }  
        }
        catch
        {
            Console.Clear();
            Console.WriteLine("atenção!!");
            Console.WriteLine("Usar somente numeros!!");
        }
        }
            Console.Clear();
        }
            
    }
            
        Console.Clear();
    }
}

